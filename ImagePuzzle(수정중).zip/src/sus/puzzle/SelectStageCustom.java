package sus.puzzle;

import sus.main.R;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;

/** 3-2. 게임모드-Gallery 화면 **/
public class SelectStageCustom extends Activity {
	int REQUEST_GET_PHOTO = 0;
	ArrayAdapter<CharSequence> adSpinPiece;
	ArrayAdapter<CharSequence> adSpinTime;
	ImageView ivImage;
	Spinner spPiece;
	Spinner spTimeLimit;
	EditText etPiece;
	Button btStartSelected;
	int imageId;
	int piece;
	int timelimit;
	int movelimit;
	Bitmap selPhoto;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.selectstagecustom);

		ivImage = (ImageView) findViewById(R.id.ivSelected);
		btStartSelected = (Button) findViewById(R.id.btStartSelected);
		spPiece = (Spinner) findViewById(R.id.spPiece);
		spTimeLimit = (Spinner) findViewById(R.id.spTime);
		adSpinPiece = ArrayAdapter.createFromResource(this, R.array.piece, android.R.layout.simple_spinner_item);
		adSpinTime = ArrayAdapter.createFromResource(this, R.array.time, android.R.layout.simple_spinner_item);
		etPiece = (EditText) findViewById(R.id.etPiece);
		
		Drawable mDrawable = getResources().getDrawable(R.drawable.warring);
		ivImage.setImageDrawable(mDrawable);

		adSpinPiece.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spPiece.setAdapter(adSpinPiece);
		adSpinTime.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spTimeLimit.setAdapter(adSpinTime);

		setWidgetListener();
	}

	// 사진첩 정보 가져오기
	void setWidgetListener() {
		ivImage.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				Intent intent = new Intent(Intent.ACTION_PICK);
				intent.setType("image/*");
				intent.putExtra("crop", "true");
				intent.putExtra("aspectX", 1);
				intent.putExtra("aspectY", 1);
				intent.putExtra("noFaceDetection", true);
				intent.putExtra("return-data", true);
				startActivityForResult(intent, REQUEST_GET_PHOTO);
			}
		});
		
		// 사진분할 설정
		spPiece.setOnItemSelectedListener(new OnItemSelectedListener() {
			public void onItemSelected(AdapterView<?> parent, View view, int positon, long id) {
				switch (positon) {
				case 0: // Piece-3x3
					piece = 3;
					break;
				case 1: // Piece-4x4
					piece = 4;
					break;
				case 2: // Piece-5x5
					piece = 5;
					break;
				case 3: // Piece-Custom
					etPiece.setVisibility(View.VISIBLE);
					break;
				}
			}
			// Piece-기본 선택(3x3)
			public void onNothingSelected(AdapterView<?> parent) {
				piece = 3;
			}
		});

		// 시간 설정
		spTimeLimit.setOnItemSelectedListener(new OnItemSelectedListener() {
			public void onItemSelected(AdapterView<?> parent, View view, int positon, long id) {
				switch (positon) {
				case 0: // Limit-90초
					timelimit = 90;
					break;
				case 1: // Limit-150초
					timelimit = 150;
					break;
				case 2: // Limit-300초
					timelimit = 300;
					break;
				case 3: // Limit-없음
					timelimit = 0;
					break;
				}
			}

			// Limit-기본선택(90초)
			public void onNothingSelected(AdapterView<?> parent) {
				timelimit = 0;
			}
		});
	}

	// 실행 버튼
	public void mOnClick(View v) {
		switch (v.getId()) {
		// Start 버튼
		case R.id.btStartSelected:
			Intent intent = new Intent(SelectStageCustom.this, MyPuzzle.class);
			intent.putExtra("bitmapimage", selPhoto);
			intent.putExtra("image", imageId);
			if (etPiece.getVisibility() == 0)
				piece = Integer.parseInt(etPiece.getText().toString());
			intent.putExtra("piece", piece);
			intent.putExtra("timelimit", timelimit);
			startActivity(intent); // SelectStageCustom에서 MyPuzzle화면으로 이동
			break;
		}
	}

	// 선택된 사진스케일조정
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == REQUEST_GET_PHOTO) {
			if (data != null) {
				try {
					selPhoto = (Bitmap) data.getExtras().get("data");
					selPhoto = Bitmap.createScaledBitmap(selPhoto, 300, 300, true);
					ivImage.setImageBitmap(selPhoto);
				} catch (Exception e) {
					;
				}
			}
		}
	}
}
