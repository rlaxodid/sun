package sus.puzzle;

import java.util.Vector;

import sus.main.R;
import sus.puzzle.MyPuzzle.BackThread;
import sus.puzzle.myPuzzleView.PuzzlePiece;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

public class Game {
	LinearLayout puzzleLinear;
	ProgressBar pgTime;
	TextView tvMove;
	int[][] PuzzleMap;
	boolean initTag;
	Vector<PuzzlePiece> vtPiece;
	int mImageID;
	int mPiece;		
	int blockSize;
	int mWid, mHei, mLen;
	int mTime, mMove;
	BackThread mThread;
	int blank_x, blank_y;
	Bitmap myImage = null;

	
}
