package sus.puzzle;

import sus.main.R;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

/** 1. 첫 메인 화면 **/
public class Main extends Activity {
	LinearLayout mainLinear;
	static int mWid, mHei, mLen;
	@Override
	protected void onCreate(Bundle savedInstanceState) { 
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		ImageButton btStart = (ImageButton)findViewById(R.id.btStart);
		ImageButton btExti = (ImageButton)findViewById(R.id.btExit);
		//btStart.setOnClickListener(mClickListener);
		//btExti.setOnClickListener(mClickListener);
		
		WindowManager wm = (WindowManager)getSystemService(Context.WINDOW_SERVICE);
		Display d = wm.getDefaultDisplay();
		mHei = d.getHeight();
		mWid = d.getWidth();
		if (mWid > mHei)
			mLen = mHei;
		else
			mLen = mWid;
	}
	// 실행 버튼
	public void mOnClick(View v) {
		switch(v.getId()) {
		// Start 버튼
		case R.id.btStart:
			Intent intent = new Intent(Main.this, SelectTab.class);
			startActivity(intent); // 메인화면에서 SelectTab 화면으로 이동
			break;
		// EXIT 버튼
		case R.id.btExit:
			// 앱 종료
			finish();
			break;
		}
	}
}