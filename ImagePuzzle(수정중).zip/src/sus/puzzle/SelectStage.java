package sus.puzzle;

import sus.main.R;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Gallery;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.AdapterView.OnItemSelectedListener;

/** 3-1. 게임모드-Practice 화면 **/
public class SelectStage extends Activity {
	ArrayAdapter<CharSequence> adSpinPiece;
	ArrayAdapter<CharSequence> adSpinTime;
	Gallery gallery;
	Spinner spPiece;
	Spinner spTimeLimit;
	EditText etPiece;
	Button btStartSelected;
	int imageId;
	int piece;
	int timelimit;
	int movelimit;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.selectstage);
		
		etPiece = (EditText) findViewById(R.id.etPiece);
		gallery = (Gallery) findViewById(R.id.gallery);
		gallery.setAdapter(new ImageAdapter(this));
		spPiece = (Spinner) findViewById(R.id.spPiece);
		spTimeLimit = (Spinner) findViewById(R.id.spTime);
		adSpinPiece = ArrayAdapter.createFromResource(this, R.array.piece, android.R.layout.simple_spinner_item);
		adSpinTime = ArrayAdapter.createFromResource(this, R.array.time, android.R.layout.simple_spinner_item);
		btStartSelected = (Button) findViewById(R.id.btStartSelected);
		
		adSpinPiece.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spPiece.setAdapter(adSpinPiece);		
		adSpinTime.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spTimeLimit.setAdapter(adSpinTime);

		setWidgetListener();
	}
	
	void setWidgetListener() {
		gallery.setOnItemSelectedListener(new OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				imageId = (int) gallery.getItemIdAtPosition(position);
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				imageId = (int) gallery.getItemIdAtPosition(0);
			}
		});

		
		spPiece.setOnItemSelectedListener(new OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> parent, View view, int positon, long id) {
				switch (positon) {
				case 0: // Piece-3x3
					piece = 3;
					break;
				case 1: // Piece-4x4
					piece = 4;
					break;
				case 2: // Piece-5x5
					piece = 5;
					break;
				case 3: // Piece-Custom
					etPiece.setVisibility(View.VISIBLE);
					break;
				}
			}
			// Piece-기본 선택(3x3)
			public void onNothingSelected(AdapterView<?> parent) {
				piece = 3;
			}
		});

		spTimeLimit.setOnItemSelectedListener(new OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> parent, View view,
					int positon, long id) {
				switch (positon) {
				case 0: // Limit-90초
					timelimit = 90;
					break;
				case 1: // Limit-150초
					timelimit = 150;
					break;
				case 2: // Limit-300초
					timelimit = 300;
					break;
				case 3: // Limit-없음
					timelimit = 0;
					break;
				}
			}

			// Limit-기본선택(90초)
			public void onNothingSelected(AdapterView<?> parent) {
				timelimit = 0;
			}
		});
	}

	// 실행 버튼
	public void mOnClick(View v) {
		switch (v.getId()) {
		// Start 버튼
		case R.id.btStartSelected:
			Intent intent = new Intent(SelectStage.this, MyPuzzle.class);
			intent.putExtra("image", imageId);
			if (etPiece.getVisibility() == 0)
				piece = Integer.parseInt(etPiece.getText().toString());
			intent.putExtra("piece", piece);
			intent.putExtra("timelimit", timelimit);
			startActivity(intent); // SelectStage에서 MyPuzzle화면으로 이동
			break;
		}
	}

	class ImageAdapter extends BaseAdapter {
		private Context mContext;
		private int[] mImageIds = { 
				R.drawable.codegears001, R.drawable.codegears002, 
				R.drawable.codegears003, R.drawable.codegears004, 
				R.drawable.codegears005, R.drawable.codegears006, 
				R.drawable.codegears007, R.drawable.codegears008, 
				R.drawable.codegears009, R.drawable.codegears010, 
				R.drawable.codegears011, R.drawable.codegears012, 
				R.drawable.codegears013, R.drawable.codegears014, 
				R.drawable.codegears015, R.drawable.codegears016, 
				R.drawable.codegears017, R.drawable.codegears018, 
				R.drawable.codegears019, R.drawable.codegears020 
		};

		public ImageAdapter(Context c) {
			mContext = c;
		}

		public int getCount() {
			return mImageIds.length;
		}

		public Object getItem(int position) {
			return mImageIds[position];
		}

		public long getItemId(int position) {
			return mImageIds[position];
		}

		public View getView(int position, View convertView, ViewGroup parent) {
			ImageView imageView;

			if (convertView == null) {
				imageView = new ImageView(mContext);
			} else {
				imageView = (ImageView) convertView;
			}

			imageView.setImageResource(mImageIds[position]);
			imageView.setScaleType(ImageView.ScaleType.FIT_XY);
			int size = (int) (Main.mLen * 0.7);
			imageView.setLayoutParams(new Gallery.LayoutParams(size, size));

			return imageView;
		}
	}
}
