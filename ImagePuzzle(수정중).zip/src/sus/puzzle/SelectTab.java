package sus.puzzle;

import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TabHost;

/** 2. 게임선택 **/ 
public class SelectTab extends TabActivity {
	TabHost tabs;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);

		tabs = getTabHost();
		// 탭화면1, Practice 화면, SelectStage 화면으로 이동
		tabs.addTab(tabs.newTabSpec("Tab1")
				.setIndicator("Practice")
				.setContent(new Intent(this, SelectStage.class)));
		
		// 탭화면2, Gallery 화면, SelectStageCustom 화면으로 이동
		tabs.addTab(tabs.newTabSpec("Tab2")
				.setIndicator("Gallery")
				.setContent(new Intent(this, SelectStageCustom.class)));
	}
}
