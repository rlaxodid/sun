﻿package sus.puzzle;

import java.util.Random;
import java.util.Vector;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Paint.Style;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

/** 4.1 보여지는 게임 부분 **/ 
class myPuzzleView extends View {
	MyPuzzle mPuzzle;
	Bitmap mImage;
	Handler mHandler;
	boolean pieceInit;

	public myPuzzleView(Context context, Handler handler) {
		super(context);
		mPuzzle = (MyPuzzle) context;
		mHandler = handler;
		init();
	}

	// 선택된 사진 분할
	void init() {
		pieceInit = false;
		if (mPuzzle.myImage == null) {
			mImage = BitmapFactory.decodeResource(getResources(),
					mPuzzle.mImageID);
		} else {
			mImage = mPuzzle.myImage;
		}

		mImage = Bitmap.createScaledBitmap(mImage, mPuzzle.mLen, mPuzzle.mLen,
				true);
		mPuzzle.PuzzleMap = new int[mPuzzle.mPiece][mPuzzle.mPiece];
		mPuzzle.vtPiece = new Vector<PuzzlePiece>();
		Bitmap tmpBit;
		boolean tag;
		for (int i = 0; i < mPuzzle.mPiece; i++) {
			for (int j = 0; j < mPuzzle.mPiece; j++) {
				// 마지막 조각은 블랭크
				if (i * j == (mPuzzle.mPiece - 1) * (mPuzzle.mPiece - 1)) {
					tmpBit = null;
					tag = true;
				} else {
					tmpBit = Bitmap.createBitmap(mImage, i * mPuzzle.blockSize,
							j * mPuzzle.blockSize, mPuzzle.blockSize,
							mPuzzle.blockSize);
					tag = true;
				}
				mPuzzle.vtPiece.add((i * mPuzzle.mPiece) + j, new PuzzlePiece(
						tmpBit, tag));
				mPuzzle.PuzzleMap[i][j] = (i * mPuzzle.mPiece) + j;
			}
		}
	}

	// 분할된 사진 섞기
	void pieceShuffle() {
		Random r = new Random();
		int blank_x = mPuzzle.mPiece - 1;
		int blank_y = mPuzzle.mPiece - 1;
		for (int i = 0; i < mPuzzle.mPiece * 100; i++) {
			int mx = r.nextInt(3) - 1;
			int my = r.nextInt(3) - 1;
			if (!(mPuzzle.mPiece <= blank_x + mx || 0 > blank_x + mx)) {
				int tmp = mPuzzle.PuzzleMap[blank_x][blank_y];
				mPuzzle.PuzzleMap[blank_x][blank_y] = mPuzzle.PuzzleMap[blank_x
						+ mx][blank_y];
				mPuzzle.PuzzleMap[blank_x + mx][blank_y] = tmp;
				blank_x += mx;
			}
			if (!(mPuzzle.mPiece <= blank_y + my || 0 > blank_y + my)) {
				int tmp = mPuzzle.PuzzleMap[blank_x][blank_y];
				mPuzzle.PuzzleMap[blank_x][blank_y] = mPuzzle.PuzzleMap[blank_x][blank_y
						+ my];
				mPuzzle.PuzzleMap[blank_x][blank_y + my] = tmp;
				blank_y += my;
			}
		}
	}

	public boolean onTouchEvent(MotionEvent event) {
		if (event.getAction() == MotionEvent.ACTION_DOWN) {
			int x = (int) (event.getX() / mPuzzle.blockSize);
			int y = (int) (event.getY() / mPuzzle.blockSize);
			if (mPuzzle.moveNext(x, y)) {
				mPuzzle.mMove++;
				mHandler.sendEmptyMessage(1);
				// 사운드 소리 처리
			} else {
				// 못움직일때 소리 처리
			}
			mPuzzle.moveNext(x, y);
			invalidate();
			if (mPuzzle.checkGameOver()) {
				// 게임끝 사운드 처리
				Toast.makeText(mPuzzle, "Complete", Toast.LENGTH_SHORT).show();
				invalidate();
			}
			return true;
		}
		return false;
	}

	public myPuzzleView(Context context, int cropCount) {
		super(context);
		mPuzzle = (MyPuzzle) context;
		mPuzzle.mPiece = cropCount;
		init();
	}

	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		if (MeasureSpec.getMode(widthMeasureSpec) != MeasureSpec.UNSPECIFIED) {
			setMeasuredDimension(getSuggestedMinimumWidth(),
					getSuggestedMinimumHeight());
		} else {
			setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec),
					MeasureSpec.getSize(heightMeasureSpec));
		}
	}

	class PuzzlePiece {
		PuzzlePiece(Bitmap bmp, boolean tag) {
			this.tag = tag;
			imagePiece = bmp;
		}
		boolean tag;
		Bitmap imagePiece;
	}

	// 화면 출력
	protected void onDraw(Canvas canvas) {
		// TODO Auto-generated method stub
		canvas.drawColor(Color.WHITE);
		PuzzlePiece tmp;
		Bitmap tmpBit;
		Paint paint = new Paint();
		paint.setColor(Color.BLACK);
		paint.setStyle(Style.STROKE);
		paint.setStrokeWidth(1);
		for (int i = 0; i < mPuzzle.mPiece; i++) {
			for (int j = 0; j < mPuzzle.mPiece; j++) {
				tmp = mPuzzle.vtPiece.get(mPuzzle.PuzzleMap[i][j]);
				tmpBit = tmp.imagePiece;
				if (tmpBit != null) {
					canvas.drawBitmap(tmpBit, null, new Rect(i
							* mPuzzle.blockSize, j * mPuzzle.blockSize, (i + 1)
							* mPuzzle.blockSize, (j + 1) * mPuzzle.blockSize),
							null);
				}
				canvas.drawRect(i * mPuzzle.blockSize, j * mPuzzle.blockSize, i
						* mPuzzle.blockSize + mPuzzle.blockSize, j
						* mPuzzle.blockSize + mPuzzle.blockSize, paint);

			}
		}
		if (!pieceInit) {
			pieceShuffle();
			pieceInit = true;
		}
	}
}